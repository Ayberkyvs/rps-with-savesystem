import jdk.jfr.Experimental;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.nio.Buffer;
import java.util.Scanner;

import static java.nio.file.Files.createFile;
import static java.nio.file.Files.getAttribute;

public class oyun {
    private int turSayi;
    private int botskor;
    private int plSkor;
    private File dosya;
    bot bot = new bot();
    kullanici pl = new kullanici();

    public oyun(){
        dosya = new File("skorlar.txt");
        try{
            if(!dosya.exists()){
                dosya.createNewFile();
            }
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void menu(){
        if (dosya.length() == 0){
            createFile();
        }
        else {
            Scanner sc = new Scanner(System.in);
            System.out.println("---==== Save bulundu. Kaldığın yerden devam etmek ister misin? ---====\n" +
                    "1- Evet\n" +
                    "2- Hayır\n");
            while (true){
                switch (sc.nextInt()){
                    case 1:
                        System.out.println("Devam Ediliyor...");
                        veriOku();
                        baslat();
                    case 2:
                        System.out.println("Yeni Oyun Başlatılıyor...");
                        deleteFile();
                        menu();
                    default:
                        System.out.println("Lütfen tekrar deneyiniz.");
                }
                break;
            }
        }
    }
    public void baslat(){
        veriOku();
        while (botskor < turSayi && plSkor < turSayi) {
            int plSecim = pl.oyna();
            int botSecim = bot.oyna();

            if ((plSecim == 2 && botSecim == 1) ||
                (plSecim == 3 && botSecim == 2) ||
                    (plSecim == 1 && botSecim == 3)) {
                System.out.println("Kullanıcı Kazandı\n");
                skorEkle(0);
                veriOku();
            }
            else if (plSecim == botSecim){
                System.out.println("Berabere kaldı.\n");
                skorEkle(2);
                veriOku();
            }
            else {
                System.out.println("Bot Kazandı.\n");
                skorEkle(1);
                veriOku();
            }
            System.out.println("---==== Güncel Skor ====---\n" +
                    "Kullanıcı = " + plSkor + "\n" + "Bot = " + botskor + "\n");
        }
        if (botskor == turSayi) {
            System.out.println("Bot Kazandı, Sıfırlanıyor!");
            deleteFile();
        }
        else if (plSkor == turSayi) {
            System.out.println("Kullanıcı Kazandı, Sıfırlanıyor!");
            deleteFile();
        }

    }

    private void deleteFile() {
        try{
            FileWriter fw = new FileWriter(dosya,false);
            fw.close();
            this.plSkor = 0;
            this.botskor= 0;
            this.turSayi= 0;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    private void createFile() {
        try {
        Scanner sc = new Scanner(System.in);
        System.out.println("Lütfen kaçta biteceğini giriniz.");
        int kullaniciturSayi = sc.nextInt();
        if (kullaniciturSayi <= 10 && kullaniciturSayi > 0){
            String metin = "0"+";"+"0"+";"+"0"+";"+kullaniciturSayi;
            FileWriter fw = new FileWriter(dosya,false);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(metin);
            bw.close();
            fw.close();
            baslat();
        }else System.out.println("Geçersiz sayı girdiniz.Tur sayisi 1-10 olabilir.");
        }catch (Exception e){
            System.out.println("Location: Dosya Oluşturma" + e.getMessage());
        }
    }

    private void veriOku() {
        try{
            String metin = dosyaOku();
            String[] dizi = metin.split(";");
            this.turSayi = (Integer.parseInt(dizi[3]));
            this.plSkor = (Integer.parseInt(dizi[0]));
            this.botskor = (Integer.parseInt(dizi[1]));
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
    private void skorEkle(int i) {
            // 0;1;2;3
        String[] dizi = {"0","0","0","0"};
        String skorlar = dosyaOku();
        dizi = skorlar.split(";");
        if (i == 0) dizi[0] = ""+(Integer.parseInt(dizi[0])+1);
        else if (i == 1) dizi[1] = ""+(Integer.parseInt(dizi[1])+1);
        else if (i == 2) dizi[2] = ""+(Integer.parseInt(dizi[2])+1);
        String metin = dizi[0] + ";" + dizi[1] + ";" + dizi[2] + ";" + this.turSayi;
        dosyaYaz(metin);
    }

    private void dosyaYaz(String metin) {
        try{
            FileWriter fw = new FileWriter(dosya,false);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(metin);
            bw.close();
            fw.close();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    private String dosyaOku() {
        try{
            Scanner scanner = new Scanner(dosya);
            return scanner.nextLine();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        return "";
    }
}
