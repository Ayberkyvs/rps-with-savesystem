import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("\n" +
                "██╗░░░██╗░█████╗░██╗░░░██╗░█████╗░░██████╗\n" +
                "╚██╗░██╔╝██╔══██╗██║░░░██║██╔══██╗██╔════╝\n" +
                "░╚████╔╝░███████║╚██╗░██╔╝███████║╚█████╗░\n" +
                "░░╚██╔╝░░██╔══██║░╚████╔╝░██╔══██║░╚═══██╗\n" +
                "░░░██║░░░██║░░██║░░╚██╔╝░░██║░░██║██████╔╝\n" +
                "░░░╚═╝░░░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═════╝░\n" +
                "Save sistemli T,K,M oyununa hoşgeldiniz.\n" +
                "Website : https://ayberkyavas.com\n" +
                "Github : https://github.com/Ayberkyvs\n");
        oyun oyun = new oyun();
        oyun.menu();
    }
}