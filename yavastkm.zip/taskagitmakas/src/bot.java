import java.util.Random;
import java.util.Scanner;

public class bot {
    public int oyna(){
        Random rnd = new Random();
        int secim = rnd.nextInt(1,4);
        if (secim == 1) System.out.println("Bot : Taş seçti.");
        if (secim == 2) System.out.println("Bot : Kağıt seçti.");
        if (secim == 3) System.out.println("Bot : Makas seçti.");
        return secim;
    }
}
