import javax.sound.midi.SysexMessage;
import java.util.Scanner;

public class kullanici {
    public int oyna(){
        Scanner sc = new Scanner(System.in);
        int secim = 0;
        while (true){
            System.out.println("---==== Hamleni Yap ====---\n" +
                    "1- Taş\n" +
                    "2- Kağıt\n" +
                    "3- Makas\n" +
                    "Seçim Yapın.");
            secim = sc.nextInt();
            if (secim >= 1 && secim <=3)break;
            else System.out.println("Lütfen 1-3 arasında seçim yapınız.");
        }
        if (secim == 1) System.out.println("Kullanici : Taş seçti.");
        if (secim == 2) System.out.println("Kullanici : Kağıt seçti.");
        if (secim == 3) System.out.println("Kullanici : Makas seçti.");
        return secim;
    }
}
